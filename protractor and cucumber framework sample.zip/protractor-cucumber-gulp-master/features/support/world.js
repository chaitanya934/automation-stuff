'use strict';
/**
 * A module for defining variables & functions to be used across steps
 */

module.exports = function () {

};