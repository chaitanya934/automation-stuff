'use strict';

/**
 * Central place for configuration items
 */

module.exports = {

    loginDelay: 10000,
    logoutDelay: 5000,
    dashboardDelay: 20000,
    schoolwidePrefDelay: 3000

};