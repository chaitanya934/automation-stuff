module.exports = {
    username: '',
    accessKey: '',
    localUrl: 'http://localhost:3000',
    devUrl: '',
    qaUrl: 'http://cafetownsend-angular-rails.herokuapp.com',
    devApiUrl: '',
    qaApiUrl: ''
};